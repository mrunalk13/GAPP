package gapp.model.dao;

import gapp.model.Roles;

public interface RolesDao {
	
	Roles getrole(String role);

}
