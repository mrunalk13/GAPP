package gapp.model.dao;

import gapp.model.Status;

public interface StatusDao {
	
	Status getStatus(Integer id);

}
