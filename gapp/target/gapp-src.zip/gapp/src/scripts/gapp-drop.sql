
    alter table additionalField 
        drop constraint FK_8mfsbw4jtl4wtatbfdxk3pui8;

    alter table additionalFieldValue 
        drop constraint FK_keuvrj2wymkff3ur4mgqfuq4t;

    alter table additionalFieldValue 
        drop constraint FK_4kvi5jdng2xyn7tmhdcq3vaqm;

    alter table applications 
        drop constraint FK_hjxk94sfig4051etpwlkhmovo;

    alter table applications 
        drop constraint FK_pyk1en13i54d1kqesfvrrwdc1;

    alter table applications 
        drop constraint FK_kcvgm8wkufnd1xp5xd4bxkqof;

    alter table applications 
        drop constraint FK_r7tsf5girf3c3q93ria2k57cu;

    alter table applications 
        drop constraint FK_bluanikenmrafi5adj9w2oivc;

    alter table degrees 
        drop constraint FK_15by4fik7nk18bs89i5phh9m1;

    alter table gappUsers 
        drop constraint FK_1f4xf9n41phwwyll9i34oacei;

    alter table programs 
        drop constraint FK_bvnv211p91vsohkggjqtvq7kx;

    alter table statusLog 
        drop constraint FK_hqv5t6ahrx5vkjwm4ofnraie4;

    alter table statusLog 
        drop constraint FK_4v6glqpmoltdx92h55tl9t6h9;

    alter table statusLog 
        drop constraint FK_fm6jn2788xo14md0a1css7lt5;

    drop table if exists additionalField cascade;

    drop table if exists additionalFieldValue cascade;

    drop table if exists applications cascade;

    drop table if exists degrees cascade;

    drop table if exists departments cascade;

    drop table if exists gappUsers cascade;

    drop table if exists programs cascade;

    drop table if exists roles cascade;

    drop table if exists status cascade;

    drop table if exists statusLog cascade;

    drop table if exists terms cascade;

    drop sequence hibernate_sequence;
